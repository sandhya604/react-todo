import "./Footer.css";
export const Footer = () => {
  return (
    <div className="footer">
      <div>How it works</div>
      <ul>
        <li>Facebook</li>
        <li>Twitter</li>
        <li>Linkedin</li>
      </ul>
    </div>
  );
};
