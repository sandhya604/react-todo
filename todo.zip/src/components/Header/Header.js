export const Header = () => {
  return (
    <div className="px-4 py-4 bg-red-800 flex justify-between ">
      <p className="text-4xl font-bold p-0 m-0">Logo</p>
      <ul className="list-none flex">
        <li className="italic flex items-center justify-between text-2xl underline text-yellow-600">
          About US
        </li>
        <li>Contact US</li>
        <li>Pricing</li>
      </ul>
    </div>
  );
};
