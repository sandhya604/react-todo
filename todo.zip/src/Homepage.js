import { Footer } from "./components";
import { Header } from "./components";

export const HomePage = () => {
  return (
    <div>
      <Header />
      <div className="my-12 flex-col space-y-6 mx-12 flex items-center justify-center">
        <input
          placeholder="Title"
          type={"text"}
          className={
            "border-2 w-6/12 text-3xl px-4 text-sky-800 py-2 border-red-700 outline-none focus:border-green-600"
          }
        />
        <textarea
          placeholder="desciption"
          type={"text"}
          className={
            "border-2 w-6/12 text-3xl px-4 text-sky-800 py-2 border-red-700 outline-none focus:border-green-600"
          }
        />
        <button className="w-6/12 bg-red-700 py-2 rounded-lg hover:scale-105 transition-all ease-in-out">
          Submit
        </button>
      </div>
      <Footer />
    </div>
  );
};
