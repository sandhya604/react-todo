import "./App.css";
import { HomePage } from "./Homepage";
function App() {
  return <HomePage />;
}

export default App;
